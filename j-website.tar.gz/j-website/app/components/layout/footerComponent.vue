<template>
  <v-footer class="footer" color="#2b2b2b">
    
    <div class="vertical-line left" />
    <div class="vertical-line right" />
    <div class="footer-container">

      <!-- Contact -->
      <section class="footer-section">
        <v-icon
          icon="mdi-map-marker-outline"
          size="22"
          class="section-icon"
        />

        <div>
          <h3>Contact us</h3>

          <p>info@jtamotors.qa</p>
          <p>+974 1234567</p>
          <p>
            Level 20, Al Gassar Tower,
            Majlis Al Taawon St,
            Doha, State of Qatar
          </p>
        </div>
      </section>

      <!-- Newsletter -->
      <section class="footer-section">
        <v-icon
          icon="mdi-email-outline"
          size="22"
          class="section-icon"
        />

        <div class="newsletter">
          <h3>Newsletter</h3>

          <div class="newsletter-form">
            <v-text-field
              placeholder="Sign up for the newsletter"
              density="compact"
              variant="outlined"
              hide-details
            />

            <v-btn
              color="#a1123c"
              rounded="0"
              height="40"
            >
              Get notified
            </v-btn>
          </div>

          <p class="newsletter-text">
            You will receive the latest updates from our products.
          </p>
        </div>
      </section>

    </div>
  </v-footer>
</template>

<script setup lang="ts">
</script>

<style scoped>

.footer {
  background: #2d2d2d;
  color: white;
  padding: 56px 24px;
}

.footer-container {
  max-width: 1280px;
  margin: auto;

  display: grid;
  grid-template-columns: repeat(2,1fr);
  gap: 80px;
}

.footer-section {
  display: flex;
  align-items: flex-start;
  gap: 18px;
}

.section-icon {
  margin-top: 3px;
  color: white;
}

h3 {
  font-size: 20px;
  font-weight: 500;
  margin-bottom: 14px;
}

p {
  color: #b8b8b8;
  line-height: 1.7;
  margin-bottom: 6px;
  font-size: 14px;
}

.newsletter-form {
  display: flex;
  gap: 0;
  margin: 18px 0;
}

.newsletter-form :deep(.v-field) {
  border-radius: 0;
  background: transparent;
}

.newsletter-form :deep(input) {
  color: white;
}

.newsletter-form :deep(.v-field__outline) {
  color: rgba(255,255,255,.2);
}

.newsletter-form .v-text-field {
  flex: 1;
}

.newsletter-text {
  margin-top: 10px;
}

@media (max-width:960px){

  .footer-container{
    grid-template-columns:1fr;
    gap:48px;
  }

}

@media (max-width:600px){

  .footer{
    padding:40px 20px;
  }

  .footer-section{
    flex-direction:column;
    gap:12px;
  }

  .newsletter-form{
    flex-direction:column;
    gap:12px;
  }

  .newsletter-form .v-btn{
    width:100%;
  }

}
.vertical-line {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 1px;
  background: #827D75;
}

.left {
  left: 8.3%;
}

.right {
  right: 8.3%;
}
</style>