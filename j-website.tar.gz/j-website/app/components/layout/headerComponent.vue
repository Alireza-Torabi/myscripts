<template>
  <v-app-bar flat height="88" class="header">
    <v-row>
      <v-spacer></v-spacer>
      <v-col cols="11" class="px-12">
        <v-row>
          <!-- Logo -->
          <div class="logo">JTA Motors</div>

          <!-- Navigation -->
          <nav class="nav">
            <a
              v-for="item in menuItems"
              :key="item.title"
              :href="item.href"
              class="nav-link"
            >
              {{ item.title }}
            </a>
          </nav>
        </v-row>
      </v-col>
      <v-spacer></v-spacer>
    </v-row>
  </v-app-bar>
</template>

<script setup lang="ts">
const menuItems = [
  {
    title: "About Us",
    href: "#",
  },
  {
    title: "Technology & Mobility Platforms",
    href: "#",
  },
  {
    title: "Industrial Ecosystem & Strategy",
    href: "#",
  },
  {
    title: "Contact Us",
    href: "#",
  },
];
</script>

<style scoped>
.header {
  background: white !important;
  box-shadow: none !important;
}

.logo {
  font-size: 16px;
  font-weight: 500;
  color: #111;
  margin-right: 24px;
  white-space: nowrap;
}

.nav {
  display: flex;
  align-items: center;
  gap: 42px;
}

.nav-link {
  text-decoration: none;
  color: #222;
  font-size: 16px;
  font-weight: 500;
  transition: color 0.2s ease;
  white-space: nowrap;
}

.nav-link:hover {
  color: #1976d2;
}
</style>
