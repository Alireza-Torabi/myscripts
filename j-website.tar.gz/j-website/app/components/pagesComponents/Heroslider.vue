<template>
  <section class="hero-slider">
    <v-carousel
      v-model="activeSlide"
      height="1050"
      hide-delimiter-background
      cycle
      interval="6000"
      show-arrows="hover"
    >
      <v-carousel-item
        v-for="(slide, index) in slides"
        :key="index"
        :src="slide.image"
        cover
      >
        <v-row class="overlay">
          <v-spacer></v-spacer>
          <v-col cols="8">
            <h1 class="hero-title text-white text-center">
              {{ slide.titleLine1 }}
            </h1>
            <h2
              class="hero-subtitle text-white justify-center text-center mt-n16"
            >
              {{ slide.titleLine2 }}
            </h2>
            <v-row class="mt-16">
              <v-spacer></v-spacer>
              <v-col cols="7" class="mt-16">
                <v-card
                  class="newsletter-card  pb-10 px-16"
                  max-width="650"
                  width="100%"
                  rounded="lg"
                >
                  <v-row no-gutters>
                    <v-col cols="12" class="text-center mt-10">
                      <span class="card-title text-center text-white">
                        Sign Up for our newsletter
                      </span>
                    </v-col>
                  </v-row>
                  <p class="text-white mb-4 newsletter-subtext mt-n1">
                    Sign up for our newsletter to be the first to get news about
                    our products
                  </p>

                  <v-row no-gutters align="center">
                    <v-col cols="8">
                      <v-text-field
                        placeholder="Sign up for the newsletter"
                        variant="outlined"
                        density="comfortable"
                        hide-details
                        class="newsletter-input"
                      />
                    </v-col>
                    <v-col cols="4" class="pl-2">
                      <v-btn
                        color="#8c1d40"
                        height="48"
                        block
                        class="text-none"
                        prepend-icon="mdi-bell-outline"
                        elevation="0"
                      >
                        Get notified
                      </v-btn>
                    </v-col>
                  </v-row>
                </v-card>
              </v-col>
              <v-spacer></v-spacer>
            </v-row>
          </v-col>
          <v-spacer></v-spacer>
        </v-row>
      </v-carousel-item>
    </v-carousel>
  </section>
</template>

<script setup lang="ts">
import { ref } from "vue";
import heroImage from "@/assets/images/hero.jpg";

const activeSlide = ref(0);

const slides = [
  {
    image: heroImage,
    titleLine1: "From Innovation to Export",
    titleLine2: "The New Era of Qatari Automotive Industry",
  },
  // Add more slides here if the slider has additional frames
];
</script>

<style scoped>
.hero-slider :deep(.v-carousel__controls) {
  bottom: 12px;
}

.overlay {
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.15);
}

.hero-title {
  font-size: 80px;
  font-weight: 800 !important;
  max-width: 1050;
  margin-top: 140px;
  text-shadow: 0 2px 10px rgba(0, 0, 0, 0.4);
}
.hero-subtitle {
  font-size: 80px;
  font-weight: 800 !important;
  text-shadow: 0 2px 10px rgba(0, 0, 0, 0.4);
}

.chat-badge {
  cursor: pointer;
}

.newsletter-card {
  background: rgba(255, 255, 255, 0.15) !important;
  backdrop-filter: blur(6px);
  border: 1px solid rgba(255, 255, 255, 0.25);
  margin-top: 180px;
}

.newsletter-subtext {
  opacity: 0.85;
  font-size: 16px;
  font-weight: 400 !important;
}

.newsletter-input :deep(fieldset) {
  border-color: white !important
}

.newsletter-input :deep(input) {
  color: #fff;
}
.card-title {
  font-size: 32px !important;
  font-weight: 400 !important;
}

.newsletter-input :deep(input::placeholder) {
  color: rgba(255, 255, 255, 0.7);
  opacity: 1;
}

@media (max-width: 600px) {
  .hero-title {
    font-size: 1.8rem;
  }
  .hero-subtitle {
    font-size: 1.3rem;
  }
}
</style>
