<template>
  <div class="newsletter-card">
    <h2>Sign Up for our newsletter</h2>
    <p>Sign up for our newsletter to be the first to get news about our products</p>
    <NewsletterForm />
  </div>
</template>

<script setup lang="ts">
import NewsletterForm from "./NewsletterForm.vue";
</script>
