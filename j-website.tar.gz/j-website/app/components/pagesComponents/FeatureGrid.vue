<template>
  <v-row no-gutters class="feature-section">
    <v-spacer></v-spacer>
    <v-col cols="12" md="10">
      <div class="text-center mb-12">
        <h1 class="section-title">
          {{ title }}
        </h1>

        <h2 class="section-subtitle">
          {{ subtitle }}
        </h2>
      </div>

      <v-row justify="center">
        <v-col v-for="item in items" :key="item.title" cols="12" sm="6" lg="4">
          <FeatureCard v-bind="item" />
        </v-col>
      </v-row>
    </v-col>
    <v-spacer></v-spacer>
  </v-row>
</template>

<script setup lang="ts">
import FeatureCard from "./FeatureCard.vue";

defineProps<{
  title: string;
  subtitle: string;
  items: {
    title: string;
    description: string;
    icon?: string;
  }[];
}>();
</script>

<style scoped>
.feature-section {
  background: #2f2f2f;
  padding: 90px 0;
}

.section-title {
  color: white;
  font-size: clamp(2.3rem, 5vw, 4rem);
  font-weight: 300;
}

.section-subtitle {
  color: white;
  margin-top: 28px;
  font-size: clamp(1.3rem, 2vw, 2rem);
  font-weight: 300;
}

@media (max-width: 600px) {
  .feature-section {
    padding: 60px 0;
  }
}
</style>
