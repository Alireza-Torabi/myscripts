<template>
  <v-row class="feature-banner" no-gutters>
    <v-col fluid cols="12" class="pa-0 fill-height">
      <v-row
        no-gutters
        class="fill-height"
        :class="{ 'flex-row-reverse': reverse }"
      >
        <!-- Image -->
        <v-col class="image-col">
          <v-img :src="image" cover height="100%" class="feature-image" />
        </v-col>

        <!-- Content -->
        <v-col class="content-col">
          <div class="content">
            <v-icon :icon="icon" color="#D59A2B" size="26" />

            <h2>
              {{ title }}
            </h2>

            <p>
              {{ description }}
            </p>
          </div>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    image: string;
    title: string;
    description: string;
    icon?: string;
    reverse?: boolean;
  }>(),
  {
    icon: "mdi-power",
    reverse: false,
  },
);
</script>

<style scoped>
.feature-banner {
  background: #333;
  overflow: hidden;
}

.image-col {
  min-height: 420px;
  width: 59%;
  min-width: 59%;
  max-width: 59%;
}

.feature-image {
  height: 100%;
}

.content-col {
  background: #353535;
  display: flex;
  align-items: center;
  width: 41%;
  min-width: 41%;
  max-width: 41%;
}

.content {
  max-width: 560px;
  padding: 64px;
}

.content h2 {
  margin: 18px 0 24px;
  font-size: clamp(2rem, 3vw, 3rem);
  font-weight: 300;
  color: white;
}

.content p {
  color: #dddddd;
  line-height: 1.9;
  font-size: 1rem;
}

/* Tablet */

@media (max-width: 960px) {
  .image-col {
    min-height: 300px;
    width: 100%;
    min-width: 100%;
    max-width: 100%;
  }

  .content {
    padding: 48px;
  }
}

/* Mobile */

@media (max-width: 600px) {
  .image-col {
    min-height: 240px;
    width: 100%;
    min-width: 100%;
    max-width: 100%;
  }

  .content {
    padding: 32px 24px;
  }

  .content h2 {
    font-size: 2rem;
  }
}
</style>
