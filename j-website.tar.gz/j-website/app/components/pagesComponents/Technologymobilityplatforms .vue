<template>
  <v-row fluid class="py-10" style="background-color: #f5f5f5">
    <v-col cols="12" class="text-center">
      <h1
        class="text-center font-weight-regular mb-10"
        style="font-size: 2.5rem"
      >
        Technology &amp; Mobility Platforms
      </h1>
    </v-col>
    <v-col cols="12">
      <v-row justify="center" no-gutters>
        <v-col cols="12" md="12" lg="10">
          <v-row no-gutters>
            <v-col
              v-for="(card, index) in cards"
              :key="index"
              cols="12"
              sm="6"
              md="4"
              :align="index == 1 ? 'center' : ''"
              :dir="index == 2 ? 'rtl' : 'ltr'"
            >
              <v-card
                class="h-100"
                height="660"
                elevation="0"
                rounded="lg"
                color="#ffffff"
                max-width="375"
                dir="ltr"
              >
                <v-img :src="card.image" :alt="card.title" height="308" cover />
                <v-card-title class="text-h6 font-weight-medium pt-4 text-left">
                  {{ card.title }}
                </v-card-title>
                <v-card-text class="text-body-2 text-left" style="color: #555">
                  {{ card.description }}
                </v-card-text>
              </v-card>
            </v-col>
            <v-spacer></v-spacer>
          </v-row>
        </v-col>
      </v-row>
    </v-col>
  </v-row>
</template>

<script setup lang="ts">
import tec1 from "@/assets/images/tec1.jpg";
import tec2 from "@/assets/images/tec2.jpg";
import tec3 from "@/assets/images/tec3.jpg";
const cards = [
  {
    title: "New Mobility Solutions",
    image: tec1,
    description:
      "JTA Motors takes a diversified, pragmatic, and forward-looking approach to technology. We do not view mobility through a single technological pathway; instead, we define it through a portfolio of new mobility solutions capable of responding to varied market, infrastructure, and user requirements.",
  },
  {
    title: "Flagship & Executive Platforms",
    image: tec2,
    description:
      "Our technological architecture is specifically engineered to support the grand scale and demanding performance of full-size luxury SUVs and executive flagship vehicles. By combining high-capacity EV/REEV powertrains with spacious, high-comfort cabin configurations, we deliver a commanding road presence and an uncompromised premium experience designed for the region’s distinct preferences.",
  },
  {
    title: "ADAS & Intelligent Mobility",
    image: tec3,
    description:
      "A major pillar of product development at JTA Motors is the integration of Advanced Driver Assistance Systems (ADAS) and intelligent technologies. We envision a future in which vehicles are not only means of transportation, but intelligent, connected, and safety-centered systems. For us, ADAS is not an optional feature — it is part of the very definition of product quality and future readiness.",
  },
];
</script>

<style scoped>
.v-card-title {
  white-space: normal;
  line-height: 1.3;
}
</style>
