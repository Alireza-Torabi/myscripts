<template>
  <section class="contact-section">
    <div class="vertical-line left" />
    <div class="vertical-line right" />

    <v-row class="fill-height">
      <v-spacer></v-spacer>
      <v-col cols="12" md="12" lg="11">
        <v-row justify="center" align="center">
          <v-col cols="12" md="8" lg="6" class="text-center">
            <h1 class="section-title">
              {{ title }}
            </h1>

            <h2 class="section-subtitle">
              {{ subtitle }}
            </h2>

            <p class="section-description">
              {{ description }}
            </p>

            <v-btn
              color="#8C1639"
              rounded="0"
              size="large"
              class="mt-4 px-8"
              @click="$emit('click')"
            >
              {{ buttonText }}
            </v-btn>
          </v-col>
        </v-row>
      </v-col>
      <v-spacer></v-spacer>
    </v-row>
  </section>
</template>

<script setup lang="ts">
defineEmits<{
  (e: "click"): void;
}>();

withDefaults(
  defineProps<{
    title?: string;
    subtitle?: string;
    description?: string;
    buttonText?: string;
  }>(),
  {
    title: "Contact Us",
    subtitle: "Join the Future of Mobility in Qatar",
    description:
      "JTA Motors is moving forward with a strategy grounded in engineering, strategic collaboration, and sustainable development. We welcome dialogue with industrial, technology, investment, and development partners who share our long-term vision.",
    buttonText: "Contact us",
  },
);
</script>

<style scoped>
.contact-section {
  position: relative;
  overflow: hidden;
  background: #f5f5f5;
  padding: 90px 16px;
}

.section-title {
  font-size: clamp(2.2rem, 4vw, 3.5rem);
  font-weight: 400;
  color: #111;
  margin-bottom: 10px;
}

.section-subtitle {
  font-size: clamp(1.2rem, 2vw, 1.75rem);
  font-weight: 400;
  color: #222;
  margin-bottom: 28px;
}

.section-description {
  max-width: 520px;
  margin: auto;
  color: #555;
  line-height: 1.9;
  font-size: 0.95rem;
}

.vertical-line {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 1px;
  background: #d9d9d9;
}

.left {
  left: 8.3%;
}

.right {
  right: 8.3%;
}

/* Tablet */

@media (max-width: 960px) {
  .contact-section {
    padding: 70px 24px;
  }

  .left,
  .right {
    display: none;
  }
}

/* Mobile */

@media (max-width: 600px) {
  .contact-section {
    padding: 56px 20px;
  }

  .section-description {
    font-size: 0.9rem;
  }

  .v-btn {
    width: 100%;
    max-width: 260px;
  }
}
</style>
