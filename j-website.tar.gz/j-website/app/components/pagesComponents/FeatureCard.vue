<template>
  <v-card
    class="feature-card"
    flat
    rounded="lg"
  >
    <v-card-text class="pa-6">
      <v-icon
        :icon="icon"
        color="#d39b29"
        size="24"
      />

      <h3 class="mt-4">
        {{ title }}
      </h3>

      <p class="mt-3">
        {{ description }}
      </p>
    </v-card-text>
  </v-card>
</template>

<script setup lang="ts">
withDefaults(
  defineProps<{
    title: string
    description: string
    icon?: string
  }>(),
  {
    icon: 'mdi-power',
  }
)
</script>

<style scoped>
.feature-card {
  background: #303030;
  border: 1px solid rgba(255,255,255,.12);
  transition: .25s;
  height: 100%;
}

.feature-card:hover {
  border-color: #d39b29;
  transform: translateY(-4px);
}

h3 {
  color: white;
  font-size: 1.45rem;
  font-weight: 600;
  line-height: 1.3;
}

p {
  color: #d2d2d2;
  line-height: 1.7;
  font-size: .95rem;
}
</style>