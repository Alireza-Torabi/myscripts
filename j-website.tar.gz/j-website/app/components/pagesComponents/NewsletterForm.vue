<template>
  <form class="newsletter-form" @submit.prevent="submit">
    <label class="sr-only" :for="inputId">Email address</label>
    <input
      :id="inputId"
      v-model="email"
      type="email"
      required
      placeholder="Sign up for the newsletter"
    />
    <button class="button button-primary" type="submit">
      <v-icon :icon="submitted ? 'mdi-check' : 'mdi-bell-outline'" size="18" />
      {{ submitted ? "Thank you" : "Get notified" }}
    </button>
  </form>
</template>

<script setup lang="ts">
import { ref } from "vue";

const inputId = `newsletter-${useId()}`;
const email = ref("");
const submitted = ref(false);

const submit = () => {
  if (!email.value) return;
  submitted.value = true;
};
</script>
