<template>
  <v-container fluid class="py-10 px-4 px-md-8 stone-section">
    <v-row>
      <v-spacer></v-spacer>
      <v-col cols="12" md="8" lg="8">
        <h1 class="text-h4 font-weight-regular mb-8">
          Laying the First Stone of Qatar's Automotive Industry
        </h1>
        <v-row>
          <v-col
            v-for="(card, index) in cards"
            :key="index"
            cols="12"
            class="mb-6"
          >
            <v-card class="info-card pa-6 pa-md-8" elevation="0" rounded="lg">
              <v-row align="center" no-gutters>
                <!-- Text content -->
                <v-col cols="12" md="8" :order="1" :order-md="1">
                  <h2 class="text-h5 font-weight-medium mb-2">
                    {{ card.title }}
                  </h2>
                  <h3
                    class="text-subtitle-1 font-weight-medium mb-4 card-subtitle"
                  >
                    {{ card.subtitle }}
                  </h3>
                  <p class="text-body-2 card-text">
                    {{ card.description }}
                  </p>
                </v-col>

                <!-- Graphic -->
                <v-col
                  cols="12"
                  md="4"
                  :order="0"
                  :order-md="2"
                  class="d-flex justify-center justify-md-end mb-4 mb-md-0"
                >
                  <v-img
                    :src="card.image"
                    :alt="card.imageAlt"
                    :max-width="card.imageMaxWidth"
                    contain
                  />
                </v-col>
              </v-row>
            </v-card>
          </v-col>
        </v-row>
      </v-col>
      <v-spacer></v-spacer>
    </v-row>
  </v-container>
</template>

<script setup>
import info1 from "@/assets/images/info1.png";
import info2 from "@/assets/images/info2.png";
const cards = [
  {
    title: "Establishing the First Automotive Manufacturing Plant in Qatar",
    subtitle:
      "Engineering the Next Generation of Mobility, Technology, and Industrial Growth",
    description:
      "JTA Motors is proudly paving the way as the first automotive manufacturing plant in the State of Qatar, establishing a milestone for national industrial development. Beyond vehicle production, we act as a pioneering developer of new mobility solutions, advancing diversified EV, REEV, and PHEV platforms integrated with high-level ADAS, localized supply chains, and regional export capability.",
    image: info1,
    imageAlt: "Outline map of Qatar",
    imageMaxWidth: 180,
  },
  {
    title: "Strategic Alignment",
    subtitle: "Aligned with Qatar National Vision 2030",
    description:
      "JTA Motors is more than just an automotive manufacturing plant; it is a strategic national initiative directly aligned with Qatar National Vision 2030. By focusing on advanced technology transfer, localizing industrial supply chains, developing new mobility solutions, and creating high-value technical careers, we actively contribute to Qatar's economic diversification and knowledge-based sustainable growth.",
    image: info2,
    imageAlt: "Qatar National Vision 2030 emblem",
    imageMaxWidth: 160,
  },
];
</script>

<style scoped>
.stone-section {
  background-color: #F5F5F5;
  width: 83.2% !important;
  max-width: 83.2% !important;
  min-width: 83.2% !important;
  border-left: 1px solid #D9CFBF;
  border-right: 1px solid #D9CFBF;
}

.info-card {
  background-color: #e6e6e4;
}

.card-subtitle {
  color: #3a3a3a;
}

.card-text {
  color: #555;
  line-height: 1.6;
}
.vertical-line {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 1px;
  background: #827D75;
}

.left {
  left: 8.4%;
}

.right {
  right: 8.4%;
}
</style>
