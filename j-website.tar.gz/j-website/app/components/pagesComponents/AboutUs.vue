<template>
  <v-row no-gutters class="about-section">
    <v-spacer></v-spacer>
    <v-col cols="12" md="12" lg="10" class="border-style py-14">
      <v-row align="start" class="px-16">
        <!-- Left column: text content -->
        <v-col cols="12" md="6" class="pr-md-8">
          <h1 class="text-h3 font-weight-regular mb-6 text-white">About Us</h1>

          <p class="text-body-1 mb-4 about-text">
            JTA Motors is being established to create a new generation of
            luxury, premium, and technology-driven products across the
            automotive and mobility space. We believe the future belongs to
            brands capable of integrating product, technology, safety, R&amp;D,
            supply chain, and new mobility solutions within a unified ecosystem.
          </p>

          <p class="text-body-1 mb-8 about-text">
            As the first automotive manufacturing plant and developer in Qatar,
            our mission was conceived to localize engineering expertise and
            build an advanced, safe, and luxury &amp; premium automotive sector.
            This national project represents a strategic milestone in Qatar's
            industrial and technological development vision. We are establishing
            a comprehensive ecosystem that integrates Research and Development
            (R&amp;D), engineering design for advanced powertrain platforms (EV,
            REEV, and PHEV), intelligent driver-assistance systems (high-level
            ADAS), and a resilient supply chain structure.
          </p>
        </v-col>

        <!-- Right column: world map -->
        <v-col cols="12" md="6">
          <v-img
            :src="map"
            alt="World map showing highlighted regions"
            contain
            height="260"
          />
        </v-col>
      </v-row>

      <!-- Newsletter signup -->
      <v-row class="mt-n16 px-16" justify="end">
        <v-col cols="12" md="6">
          <v-row no-gutters>
            <v-col cols="8">
              <v-text-field
                placeholder="Sign up for the newsletter"
                variant="outlined"
                density="comfortable"
                hide-details
                class="newsletter-input"
              />
            </v-col>
            <v-col cols="4">
              <v-btn
                color="#8c1d40"
                height="48"
                block
                class="text-none"
                elevation="0"
              >
                Get notified
              </v-btn>
            </v-col>
          </v-row>
        </v-col>
      </v-row>

      <!-- Vision & Mission -->
      <v-row class="mt-12 px-16">
        <v-col cols="12" md="6" class="pr-md-8">
          <v-icon
            icon="mdi-image-filter-center-focus"
            size="40"
            color="#c9974c"
            class="mb-4"
          />
          <h2 class="text-h5 font-weight-regular mb-3 text-white">Vision</h2>
          <p class="text-body-1 about-text">
            To become the premier regional manufacturer of intelligent new
            energy vehicles and to establish Qatar as a recognized global center
            for automotive innovation and sustainable mobility.
          </p>
        </v-col>

        <v-col cols="12" md="6">
          <v-icon
            icon="mdi-compass-outline"
            size="40"
            color="#c9974c"
            class="mb-4"
          />
          <h2 class="text-h5 font-weight-regular mb-3 text-white">Mission</h2>
          <p class="text-body-1 about-text">
            To design, develop, and manufacture premium, intelligent vehicles
            that combine cutting-edge technology with high-performance
            engineering, ensuring sustainable value for customers, the national
            economy, and the automotive industry.
          </p>
        </v-col>
      </v-row>
    </v-col>
    <v-spacer></v-spacer>
  </v-row>
</template>

<script setup>
import map from "@/assets/images/map.png";
</script>

<style scoped>
.about-section {
  background-color: #1c1c1c;
}

.about-text {
  color: #c9c9c9;
  line-height: 1.6;
}

.newsletter-input :deep(fieldset) {
  border-color: #555;
}

.newsletter-input :deep(input::placeholder) {
  color: #999;
  opacity: 1;
}
.border-style {
  border-right: 1px solid #827d75 !important;
  border-left: 1px solid #827d75 !important;
}
</style>
