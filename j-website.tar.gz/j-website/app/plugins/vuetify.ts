import "vuetify/styles";
import "@mdi/font/css/materialdesignicons.css";

import { createVuetify } from "vuetify";

export default defineNuxtPlugin((nuxtApp) => {
  const vuetify = createVuetify({
    theme: {
      defaultTheme: "light",
    },
    locale: {
      locale: "en",
      fallback: "en",
    },
  });

  nuxtApp.vueApp.use(vuetify);
});
