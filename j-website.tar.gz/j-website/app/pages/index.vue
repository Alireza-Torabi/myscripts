<template>
  <div
    class="landing-page"
    :style="{
      '--hero-image': `url(${heroImage})`,
      '--manufacturer-image': `url(${carInfoImage})`,
      '--factory-image': `url(${factoryImage})`,
      '--engine-image': `url(${engineImage})`,
    }"
  >
    <section id="home" class="hero">
      <div class="page-rail hero-rail">
        <header class="site-header" :class="{ 'menu-open': menuOpen }">
          <a class="brand" href="#home" aria-label="JTA Motors home">
            <img :src="logo" alt="JTA Motors" />
            <span class="mobile-brand-label">JTA Motors</span>
          </a>

          <button
            class="menu-toggle"
            type="button"
            :aria-expanded="menuOpen"
            aria-label="Toggle navigation"
            @click="menuOpen = !menuOpen"
          >
            <v-icon :icon="menuOpen ? 'mdi-close' : 'mdi-menu'" />
          </button>

          <nav class="site-nav" aria-label="Primary navigation">
            <a href="#home" @click="menuOpen = false">Home</a>
            <a href="#about" @click="menuOpen = false">About Us</a>
            <a href="#contact" @click="menuOpen = false">Contact Us</a>
          </nav>

          <a class="button button-primary header-cta" href="#contact">
            <v-icon icon="mdi-send-outline" size="18" />
            Get in touch
          </a>
        </header>

        <div class="hero-copy">
          <h1><span>From</span> <span>Innovation</span> <span>to Export</span></h1>
          <p><span>The New Era of</span> <span>Qatari Automotive</span> <span>Industry</span></p>
        </div>

        <NewsletterCard class="hero-newsletter" />
      </div>
    </section>

    <main>
      <section class="foundation light-section">
        <div class="page-rail">
          <div id="foundation-view" class="foundation-heading">
            <p>Laying the First Stone of</p>
            <h2>Qatar’s Automotive Industry</h2>
          </div>

          <article
            v-for="item in foundations"
            :key="item.title"
            class="foundation-row"
          >
            <div class="foundation-copy">
              <h3>{{ item.title }}</h3>
              <h4>{{ item.subtitle }}</h4>
              <p>{{ item.description }}</p>
            </div>
            <img :src="item.image" :alt="item.alt" />
          </article>
        </div>
      </section>

      <section class="manufacturer-banner">
        <div class="page-rail banner-copy">
          <h2>Qatar’s First Automotive Manufacturer</h2>
          <p>Engineering Quality, Luxury, and the Future.</p>
        </div>
      </section>

      <section id="about" class="about-section dark-section">
        <div class="page-rail about-rail">
          <div class="about-grid">
            <div class="about-copy">
              <h2>About Us</h2>
              <p>
                JTA Motors is being established to create a new generation of luxury,
                premium, and technology-driven products across the automotive and
                mobility space. We believe the future belongs to brands capable of
                integrating product, technology, safety, R&amp;D, supply chain, and new
                mobility solutions within a unified ecosystem.
              </p>
              <p>
                As the first automotive manufacturing plant and developer in Qatar,
                our mission was conceived to localize engineering expertise and build
                an advanced, safe, and luxury &amp; premium automotive sector. This
                national project represents a strategic milestone in Qatar’s industrial
                and technological development vision. We are establishing a
                comprehensive ecosystem that integrates Research and Development
                (R&amp;D), engineering design for advanced powertrain platforms (EV,
                REEV, and PHEV), intelligent driver-assistance systems (high-level
                ADAS), and a resilient supply chain structure.
              </p>
            </div>

            <div class="about-visual">
              <img :src="mapImage" alt="Global map with JTA Motors target regions" />
              <NewsletterForm />
            </div>
          </div>

          <div class="purpose-grid">
            <article>
              <v-icon icon="mdi-image-filter-center-focus" />
              <h3>Vision</h3>
              <p>
                To become the premier regional manufacturer of intelligent new energy
                vehicles and to establish Qatar as a recognized global center for
                automotive innovation and sustainable mobility.
              </p>
            </article>
            <article>
              <v-icon icon="mdi-bullseye-arrow" />
              <h3>Mission</h3>
              <p>
                To design, develop, and manufacture premium, intelligent vehicles that
                combine cutting-edge technology with high-performance engineering,
                ensuring sustainable value for customers, the national economy, and
                the automotive industry.
              </p>
            </article>
          </div>
        </div>
      </section>

      <section id="technology" class="technology light-section">
        <div class="page-rail technology-rail">
          <h2>Technology &amp; Mobility Platforms</h2>
          <div class="technology-grid">
            <article v-for="card in technologyCards" :key="card.title">
              <img :src="card.image" :alt="card.title" />
              <div>
                <h3>{{ card.title }}</h3>
                <p>{{ card.description }}</p>
              </div>
            </article>
          </div>
        </div>
      </section>

      <section id="strategy" class="strategy dark-gold-section">
        <div class="page-rail strategy-rail">
          <h2>Industrial Ecosystem &amp; Strategy</h2>
          <p class="strategy-kicker">Why JTA Motors?</p>
          <div class="strategy-grid">
            <article v-for="feature in features" :key="feature.title">
              <v-icon :icon="feature.icon" />
              <h3>{{ feature.title }}</h3>
              <p>{{ feature.description }}</p>
            </article>
          </div>
        </div>
      </section>

      <section class="industrial-growth">
        <div class="industrial-image" role="img" aria-label="JTA automotive factory" />
        <div class="industrial-copy">
          <v-icon icon="mdi-arrow-top-right" />
          <h2>Industrial Growth</h2>
          <p>
            We are moving beyond the product to build an industrial ecosystem.
            Meaningful growth in the automotive sector is achieved when product,
            engineering, supply chain, R&amp;D, and production capability evolve together.
            We are actively fostering a robust supply chain to ensure resilience,
            quality, and long-term sustainability.
          </p>
        </div>
      </section>

      <section id="contact" class="contact-section light-section">
        <div class="page-rail contact-rail">
          <div class="contact-copy">
            <h2>Contact Us</h2>
            <h3>Join the Future of Mobility in Qatar</h3>
            <p>
              JTA Motors is moving forward with a strategy grounded in engineering,
              strategic collaboration, and sustainable development. We welcome
              dialogue with industrial, technology, investment, and development
              partners who share our long-term vision.
            </p>
            <a class="button button-primary" href="mailto:info@jtamotors.qa">
              <v-icon icon="mdi-send-outline" size="18" />
              Get in touch
            </a>
          </div>
          <img :src="dohaImage" alt="Doha skyline" />
        </div>
      </section>

      <section class="engine-banner" aria-label="JTA Motors engineering" />
    </main>

    <footer class="site-footer dark-section">
      <div class="page-rail footer-rail">
        <section>
          <v-icon icon="mdi-at" />
          <h2>Contact us</h2>
          <a href="mailto:info@jtamotors.qa">info@jtamotors.qa</a>
          <a href="tel:+9741234567">+974 1234567</a>
          <p>Level 20, Al Gassar Tower, Majlis Al Taawon St, Doha, State of Qatar</p>
        </section>
        <section>
          <v-icon icon="mdi-rss" />
          <h2>Newsletter</h2>
          <NewsletterForm />
          <p>You will receive the latest updates from our products.</p>
        </section>
      </div>
    </footer>
  </div>
</template>

<script setup lang="ts">
import { ref } from "vue";
import NewsletterCard from "@/components/pagesComponents/NewsletterCard.vue";
import NewsletterForm from "@/components/pagesComponents/NewsletterForm.vue";
import heroImage from "@/assets/images/hero.jpg";
import carInfoImage from "@/assets/images/carInfo.jpg";
import engineImage from "@/assets/images/engine.jpg";
import factoryImage from "@/assets/images/factory.jpg";
import info1 from "@/assets/images/info1.png";
import info2 from "@/assets/images/info2.png";
import mapImage from "@/assets/images/map.png";
import logo from "@/assets/images/jta-logo.png";
import dohaImage from "@/assets/images/doha-skyline.png";
import tec1 from "@/assets/images/tec1.jpg";
import tec2 from "@/assets/images/tec2.jpg";
import tec3 from "@/assets/images/tec3.jpg";

const menuOpen = ref(false);
const foundations = [
  {
    title: "Establishing the First Automotive Manufacturing Plant in Qatar",
    subtitle: "Engineering the Next Generation of Mobility, Technology, and Industrial Growth",
    description:
      "JTA Motors is proudly paving the way as the first automotive manufacturing plant in the State of Qatar, establishing a milestone for national industrial development. Beyond vehicle production, we act as a pioneering developer of new mobility solutions, advancing diversified EV, REEV, and PHEV platforms integrated with high-level ADAS, localized supply chains, and regional export capability.",
    image: info1,
    alt: "Outline map of Qatar",
  },
  {
    title: "Strategic Alignment",
    subtitle: "Aligned with Qatar National Vision 2030",
    description:
      "JTA Motors is more than just an automotive manufacturing plant; it is a strategic national initiative directly aligned with Qatar National Vision 2030. By focusing on advanced technology transfer, localizing industrial supply chains, developing new mobility solutions, and creating high-value technical careers, we actively contribute to Qatar’s economic diversification and knowledge-based sustainable growth.",
    image: info2,
    alt: "Qatar National Vision 2030 emblem",
  },
];

const technologyCards = [
  {
    title: "New Mobility Solutions",
    image: tec3,
    description:
      "JTA Motors takes a diversified, pragmatic, and forward-looking approach to technology. We do not view mobility through a single technological pathway; instead, we define it through a portfolio of new mobility solutions capable of responding to varied market, infrastructure, and user requirements.",
  },
  {
    title: "Flagship & Executive Platforms",
    image: tec1,
    description:
      "Our technological architecture is specifically engineered to support the grand scale and demanding performance of full-size luxury SUVs and executive flagship vehicles. By combining high-capacity EV/REEV powertrains with spacious, high-comfort cabin configurations, we deliver a commanding road presence and an uncompromised premium experience designed for the region’s distinct preferences.",
  },
  {
    title: "ADAS & Intelligent Mobility",
    image: tec2,
    description:
      "A major pillar of product development at JTA Motors is the integration of Advanced Driver Assistance Systems (ADAS) and intelligent technologies. We envision a future in which vehicles are not only means of transportation, but intelligent, connected, and safety-centered systems. For us, ADAS is not an optional feature — it is part of the very definition of product quality and future readiness.",
  },
];

const features = [
  { icon: "mdi-land-plots", title: "National Milestone", description: "Establishing the first automotive manufacturing plant in Qatar." },
  { icon: "mdi-flip-horizontal", title: "Strategic Alignment", description: "Contributing directly to the goals of Qatar National Vision 2030." },
  { icon: "mdi-cpu-64-bit", title: "Diversified Technology Portfolio", description: "REEV, PHEV and EV platforms within one strategic framework." },
  { icon: "mdi-console", title: "Advanced Engineering", description: "Focus on high-level ADAS and intelligent system integration." },
  { icon: "mdi-binoculars", title: "R&D Hub", description: "Contributing directly to the goals of Qatar National Vision 2030." },
  { icon: "mdi-link-variant", title: "Industrial Ecosystem", description: "Strengthening local supply chains and forming strategic international partnerships." },
  { icon: "mdi-arrow-top-right", title: "Export Orientation", description: "Designing for regional and international markets from the outset." },
];

useHead({
  title: "JTA Motors — Qatar Automotive Manufacturing",
  meta: [
    {
      name: "description",
      content: "JTA Motors is building Qatar’s first advanced automotive manufacturing ecosystem.",
    },
  ],
});
</script>

<style scoped>
.landing-page {
  --wine: #97133c;
  --gold: #c39443;
  --paper: #f5f5f4;
  --ink: #171717;
  --dark: #292929;
  --grid-line: rgba(160, 143, 117, 0.35);
  color: var(--ink);
  background: var(--paper);
}

.page-rail {
  width: min(1200px, calc(100% - 48px));
  margin-inline: auto;
  border-inline: 1px solid var(--grid-line);
}

.hero {
  min-height: 936px;
  color: #fff;
  background: linear-gradient(rgba(25, 18, 14, 0.1), rgba(25, 18, 14, 0.1)), var(--hero-image) center / cover no-repeat;
}

.hero-rail {
  min-height: 936px;
  position: relative;
  padding-top: 16px;
}

.site-header {
  width: calc(100% - 8px);
  min-height: 78px;
  margin-inline: auto;
  padding: 8px 32px;
  display: grid;
  grid-template-columns: 137px 1fr 159px;
  align-items: center;
  gap: 32px;
  background: #fff;
  color: #1d1d1d;
  border-radius: 4px;
}

.brand img {
  display: block;
  width: 137px;
  height: 62px;
  object-fit: contain;
}

.brand { text-decoration: none; }
.mobile-brand-label { display: none; }

.site-nav {
  display: flex;
  gap: 32px;
}

.site-nav a {
  padding: 8px;
  color: inherit;
  font-size: 15px;
  text-decoration: none;
}

.site-nav a:hover,
.site-nav a:focus-visible {
  color: var(--wine);
}

.menu-toggle { display: none; }

.button {
  min-height: 48px;
  padding: 0 24px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  border: 0;
  border-radius: 0;
  font: inherit;
  font-size: 14px;
  text-decoration: none;
  cursor: pointer;
  transition: background 180ms ease, transform 180ms ease;
}

.button:hover { transform: translateY(-1px); }
.button-primary { background: var(--wine); color: #fff; }
.button-primary:hover { background: #7e0f32; }

.hero-copy {
  margin-top: 68px;
  text-align: center;
  text-shadow: 0 2px 12px rgba(0, 0, 0, 0.24);
}

.hero-copy h1 {
  font-size: clamp(44px, 6.1vw, 88px);
  line-height: 1.06;
  font-weight: 400;
  letter-spacing: -1.8px;
}

.hero-copy p {
  margin-top: 2px;
  font-size: clamp(22px, 2.65vw, 38px);
  line-height: 1.25;
  font-weight: 700;
}

:deep(.newsletter-card) {
  width: 679px;
  max-width: calc(100% - 40px);
  min-height: 232px;
  padding: 40px 64px;
  color: #fff;
  text-align: center;
  background: rgba(116, 91, 78, 0.64);
  border: 1px solid rgba(255, 255, 255, 0.16);
  border-radius: 4px;
  backdrop-filter: blur(5px);
}

:deep(.newsletter-card h2) { font-size: 28px; font-weight: 500; line-height: 1.4; }
:deep(.newsletter-card > p) { margin-top: 2px; font-size: 15px; }
:deep(.hero-newsletter) { position: absolute; left: 50%; bottom: 29px; transform: translateX(-50%); }

:deep(.newsletter-form) {
  display: grid;
  grid-template-columns: minmax(0, 1fr) auto;
  gap: 20px;
}

:deep(.newsletter-card .newsletter-form) { margin-top: 24px; }

:deep(.newsletter-form input) {
  width: 100%;
  min-height: 56px;
  padding: 0 24px;
  border: 1px solid rgba(255, 255, 255, 0.24);
  border-radius: 0;
  outline: none;
  background: transparent;
  color: inherit;
  font: inherit;
  font-size: 14px;
}

:deep(.newsletter-form input::placeholder) { color: currentColor; opacity: 0.72; }
:deep(.newsletter-form input:focus) { border-color: var(--gold); }
:deep(.newsletter-form .button) { min-width: 156px; min-height: 56px; }

.light-section { background: var(--paper); }
.dark-section { background: var(--dark); color: #fff; }

.foundation .page-rail { min-height: 857px; }
.foundation-heading { height: 164px; padding-top: 46px; text-align: center; }
.foundation-heading p { font-size: 20px; line-height: 1.35; }
.foundation-heading h2 { font-size: 32px; line-height: 1.35; font-weight: 700; }

.foundation-row {
  min-height: 342px;
  padding: 48px;
  display: grid;
  grid-template-columns: 1fr 206px;
  align-items: center;
  gap: 48px;
  border-top: 1px solid #ddd4c5;
  background: #efefed;
}

.foundation-row + .foundation-row { min-height: 327px; background: #f6f6f4; }
.foundation-copy h3 { font-size: 24px; line-height: 1.4; font-weight: 700; }
.foundation-copy h4 { margin-top: 4px; font-size: 18px; line-height: 1.55; font-weight: 500; }
.foundation-copy p { margin-top: 16px; max-width: 900px; font-size: 14px; line-height: 1.7; color: #3d3d3d; }
.foundation-row img { width: 100%; max-height: 246px; object-fit: contain; }

.manufacturer-banner {
  height: 436px;
  background: linear-gradient(rgba(0, 0, 0, 0.08), rgba(0, 0, 0, 0.12)), var(--manufacturer-image) center / cover no-repeat;
  color: #fff;
}

.banner-copy { height: 100%; display: grid; place-content: center; text-align: center; }
.banner-copy h2 { font-size: clamp(36px, 4.1vw, 56px); line-height: 1.15; font-weight: 600; }
.banner-copy p { font-size: clamp(25px, 2.4vw, 34px); line-height: 1.3; }

.about-rail { min-height: 788px; padding: 56px 64px 48px; }
.about-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; }
.about-copy h2 { font-size: 48px; line-height: 1.3; font-weight: 400; }
.about-copy p { margin-top: 16px; color: #efefef; font-size: 14px; line-height: 1.72; }
.about-visual { padding-top: 26px; }
.about-visual > img { width: 100%; height: 262px; object-fit: contain; }
.about-visual :deep(.newsletter-form) { margin-top: 32px; }
.about-visual :deep(.newsletter-form input) { color: #fff; }

.purpose-grid { margin-top: 56px; display: grid; grid-template-columns: 1fr 1fr; gap: 32px; }
.purpose-grid article { min-height: 204px; }
.purpose-grid .v-icon { color: var(--gold); font-size: 48px; }
.purpose-grid h3 { margin-top: 8px; font-size: 28px; font-weight: 500; }
.purpose-grid p { margin-top: 16px; color: #efefef; font-size: 14px; line-height: 1.75; }

.technology-rail { min-height: 860px; padding-top: 48px; }
.technology-rail > h2 { text-align: center; font-size: 48px; line-height: 1.35; font-weight: 400; }
.technology-grid { margin: 40px 8px 48px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; }
.technology-grid article { min-height: 660px; background: #fff; border-radius: 6px; overflow: hidden; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); }
.technology-grid img { width: 100%; height: 308px; object-fit: cover; display: block; }
.technology-grid article > div { min-height: 352px; padding: 16px 16px 24px; }
.technology-grid h3 { font-size: 23px; line-height: 1.45; font-weight: 700; }
.technology-grid p { margin-top: 16px; font-size: 14px; line-height: 1.72; color: #363636; }

.dark-gold-section { color: #fff; background: #443a2a; }
.strategy-rail { min-height: 904px; padding: 84px 8px 48px; }
.strategy-rail > h2 { text-align: center; font-size: 48px; line-height: 1.35; font-weight: 400; }
.strategy-kicker { margin-top: 32px; padding-bottom: 32px; text-align: center; font-size: 24px; border-bottom: 1px solid rgba(207, 160, 82, 0.25); }
.strategy-grid { margin-top: 48px; display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
.strategy-grid article { min-height: 185px; padding: 16px; border: 1px solid rgba(207, 160, 82, 0.2); border-radius: 5px; }
.strategy-grid article:last-child { grid-column: 2; }
.strategy-grid .v-icon { color: var(--gold); font-size: 32px; }
.strategy-grid h3 { margin-top: 8px; font-size: 22px; line-height: 1.35; font-weight: 600; }
.strategy-grid p { margin-top: 8px; color: #efede7; font-size: 15px; line-height: 1.5; }

.industrial-growth { min-height: 277px; display: grid; grid-template-columns: 1fr 1fr; color: #fff; background: #3b3b3b; }
.industrial-image { background: var(--factory-image) center / cover no-repeat; }
.industrial-copy { max-width: 600px; padding: 24px 40px; border-right: 1px solid var(--grid-line); }
.industrial-copy .v-icon { color: var(--gold); font-size: 32px; }
.industrial-copy h2 { margin-top: -4px; font-size: 30px; font-weight: 500; }
.industrial-copy p { margin-top: 24px; max-width: 544px; color: #f0f0f0; font-size: 14px; line-height: 1.72; }

.contact-rail { min-height: 455px; padding: 56px 80px; display: grid; grid-template-columns: 585px 429px; gap: 26px; align-items: center; }
.contact-copy h2 { font-size: 48px; line-height: 1.3; font-weight: 400; }
.contact-copy h3 { font-size: 25px; line-height: 1.4; font-weight: 500; }
.contact-copy p { max-width: 538px; margin-top: 22px; font-size: 14px; line-height: 1.75; color: #444; }
.contact-copy .button { margin-top: 26px; }
.contact-rail > img { width: 429px; height: 343px; object-fit: cover; border-radius: 4px; }

.engine-banner { height: 451px; background: var(--engine-image) center / cover no-repeat; }

.footer-rail { min-height: 256px; padding: 56px 64px 40px; display: grid; grid-template-columns: 1fr 1fr; gap: 32px; }
.footer-rail section { position: relative; padding-top: 40px; }
.footer-rail section > .v-icon { position: absolute; top: 0; left: 0; font-size: 32px; }
.footer-rail h2 { font-size: 24px; line-height: 1.35; font-weight: 500; }
.footer-rail a, .footer-rail p { display: block; color: #f0f0f0; font-size: 13px; line-height: 1.7; text-decoration: none; }
.footer-rail section > p { max-width: 520px; }
.footer-rail :deep(.newsletter-form) { margin: 8px 0; }
.footer-rail :deep(.newsletter-form input) { min-height: 52px; color: #fff; }
.footer-rail :deep(.newsletter-form .button) { min-height: 56px; }

.sr-only { position: absolute; width: 1px; height: 1px; padding: 0; margin: -1px; overflow: hidden; clip: rect(0, 0, 0, 0); white-space: nowrap; border: 0; }

@media (max-width: 960px) {
  .page-rail { width: calc(100% - 32px); }
  .site-header { grid-template-columns: 137px 1fr auto; padding-inline: 20px; }
  .menu-toggle { display: inline-grid; place-items: center; justify-self: end; border: 0; background: transparent; font-size: 28px; }
  .site-nav { display: none; position: absolute; z-index: 5; top: 88px; left: 4px; right: 4px; padding: 16px; background: #fff; flex-direction: column; gap: 4px; }
  .site-header.menu-open .site-nav { display: flex; }
  .header-cta { display: none; }
  .hero-copy { margin-top: 180px; }
  .foundation-row { grid-template-columns: 1fr 150px; }
  .about-grid, .purpose-grid, .industrial-growth, .contact-rail, .footer-rail { grid-template-columns: 1fr; }
  .about-rail { padding-inline: 40px; }
  .technology-grid { grid-template-columns: 1fr; }
  .technology-grid article { min-height: auto; display: grid; grid-template-columns: 38% 1fr; }
  .technology-grid img { height: 100%; min-height: 320px; }
  .technology-grid article > div { min-height: auto; padding: 44px 28px; }
  .strategy-grid { grid-template-columns: repeat(2, 1fr); }
  .strategy-grid article:last-child { grid-column: auto; }
  .industrial-growth { grid-template-columns: 1fr 1fr; }
  .contact-rail { padding-inline: 48px; }
  .contact-rail > img { width: 100%; }
}

@media (max-width: 640px) {
  .page-rail { width: 100%; border-inline: 0; }

  .hero,
  .hero-rail { height: 829px; min-height: 829px; }
  .hero { background-position: center 36%; background-size: auto 108%; }
  .hero-rail { padding-top: 0; }
  .site-header {
    width: 100%;
    height: 48px;
    min-height: 48px;
    margin: 0;
    padding: 0 16px;
    grid-template-columns: 40px 105px 1fr;
    gap: 16px;
    border-radius: 0;
  }
  .menu-toggle {
    grid-column: 1;
    grid-row: 1;
    justify-self: start;
    width: 24px;
    height: 24px;
    padding: 0;
    color: #171717;
    font-size: 20px;
  }
  .brand { grid-column: 2; grid-row: 1; }
  .brand img { display: none; }
  .mobile-brand-label {
    display: block;
    padding-left: 10px;
    color: #111;
    font-size: 16px;
    line-height: 40px;
    font-weight: 700;
    white-space: nowrap;
  }
  .site-nav { top: 48px; left: 0; right: 0; }
  .hero-copy {
    display: block;
    width: 100%;
    max-width: 361px;
    margin: 48px auto 0;
    padding-inline: 8px;
    text-align: center;
  }
  .hero-copy h1 {
    max-width: 340px;
    margin-inline: auto;
    font-family: Arial, sans-serif;
    font-size: 47px;
    line-height: 59px;
    font-weight: 700;
    letter-spacing: -1px;
  }
  .hero-copy p {
    max-width: 350px;
    margin: 0 auto;
    font-family: Arial, sans-serif;
    font-size: 35px;
    line-height: 45px;
    font-weight: 400;
  }
  .hero-copy h1 span,
  .hero-copy p span { display: block; }
  :deep(.hero-newsletter) {
    display: block;
    z-index: 2;
    bottom: -157px;
  }
  :deep(.newsletter-card) {
    width: 361px;
    max-width: calc(100% - 32px);
    height: 371px;
    min-height: 371px;
    padding: 42px 16px 39px;
    background: linear-gradient(
      180deg,
      rgba(167, 130, 98, 0.92) 0%,
      rgba(128, 100, 84, 0.9) 48%,
      rgba(255, 255, 255, 0.96) 72%,
      rgba(255, 255, 255, 0.98) 100%
    );
    border-color: rgba(80, 80, 80, 0.32);
    border-radius: 8px;
    backdrop-filter: blur(5px);
  }
  :deep(.newsletter-card h2) { font-size: 30px; line-height: 40px; font-weight: 400; }
  :deep(.newsletter-card > p) { margin-top: 5px; font-size: 16px; line-height: 25px; }
  :deep(.newsletter-card .newsletter-form) { margin-top: 21px; }
  :deep(.newsletter-card .newsletter-form input) { height: 56px; min-height: 56px; }

  .foundation .page-rail { min-height: 1299px; padding-bottom: 40px; }
  .foundation,
  .foundation .page-rail,
  .foundation-heading,
  .foundation-row,
  .foundation-row + .foundation-row { background: #fff; }
  .foundation-heading { height: 319px; padding: 183px 16px 0; }
  .foundation-heading { scroll-margin-top: 162px; }
  .foundation-heading p { font-size: 24px; line-height: 32px; font-weight: 400; transform: translateY(-4px); }
  .foundation-heading h2 { font-size: 32px; line-height: 40px; }
  .foundation-row {
    position: relative;
    height: 520px;
    min-height: 520px;
    padding: 18px 24px 24px;
    display: block;
    overflow: hidden;
    border-top: 0;
  }
  .foundation-row + .foundation-row { height: 420px; min-height: 420px; }
  .foundation-copy { position: relative; z-index: 1; }
  .foundation-copy h3 { font-size: 24px; line-height: 36px; }
  .foundation-copy h4 { width: 320px; max-width: 100%; margin-top: 8px; font-size: 21px; line-height: 28px; }
  .foundation-copy p { margin-top: 32px; color: #111; font-size: 17px; line-height: 24px; }
  .foundation-row img {
    position: absolute;
    z-index: 0;
    top: 43px;
    left: 50%;
    width: 287px;
    height: 449px;
    max-height: none;
    transform: translateX(-50%);
    object-fit: contain;
    opacity: 0.18;
  }
  .foundation-row + .foundation-row .foundation-copy h4 { margin-top: 13px; }
  .foundation-row + .foundation-row .foundation-copy h4 { width: 345px; }
  .foundation-row + .foundation-row .foundation-copy p { margin-top: 23px; }
  .foundation-row + .foundation-row img { top: 46px; width: 335px; height: 368px; opacity: 0.14; }

  .manufacturer-banner { height: 436px; }
  .banner-copy { padding-inline: 42px; }
  .banner-copy h2,
  .banner-copy p { font-size: 32px; line-height: 44px; }

  .about-section,
  .about-rail { min-height: 1647px; }
  .about-rail { padding: 40px 24px; }
  .about-grid,
  .purpose-grid { grid-template-columns: 1fr; }
  .about-grid { gap: 16px; }
  .about-copy h2 { font-size: 48px; line-height: 64px; }
  .about-copy p { margin-top: 16px; font-size: 16px; line-height: 24px; }
  .about-visual { padding-top: 0; }
  .about-visual > img { height: 171px; }
  .about-visual :deep(.newsletter-form) { margin-top: 32px; }
  :deep(.newsletter-form) { grid-template-columns: 1fr; gap: 20px; }
  :deep(.newsletter-form .button) { width: 156px; justify-self: center; }
  .purpose-grid { margin-top: 32px; gap: 32px; }
  .purpose-grid article { min-height: 228px; }
  .purpose-grid article + article { min-height: 252px; }
  .purpose-grid .v-icon { font-size: 48px; }
  .purpose-grid h3 { margin-top: 8px; font-size: 28px; line-height: 36px; }
  .purpose-grid p { margin-top: 16px; font-size: 16px; line-height: 24px; }

  .technology,
  .technology-rail { min-height: 2072px; }
  .technology-rail { padding: 48px 0; }
  .technology-rail > h2 { padding-inline: 24px; font-size: 32px; line-height: 40px; }
  .technology-grid { margin: 40px 16px 0; gap: 40px; }
  .technology-grid article { display: block; min-height: 0; border-radius: 6px; }
  .technology-grid article:nth-child(1) { height: 528px; }
  .technology-grid article:nth-child(2) { height: 636px; }
  .technology-grid article:nth-child(3) { height: 612px; }
  .technology-grid img { width: 100%; height: 308px; min-height: 0; }
  .technology-grid article > div {
    position: relative;
    min-height: 0;
    margin-top: -104px;
    padding: 80px 16px 0;
    background: #fff;
  }
  .technology-grid h3 { font-size: 24px; line-height: 36px; }
  .technology-grid p { margin-top: 16px; font-size: 16px; line-height: 24px; }

  .strategy,
  .strategy-rail { min-height: 1736px; }
  .strategy-rail { padding: 96px 16px 48px; }
  .strategy-rail > h2 { font-size: 48px; line-height: 64px; text-align: left; }
  .strategy-kicker {
    height: 16px;
    margin-top: 40px;
    padding: 0;
    overflow: hidden;
    font-size: 20px;
    line-height: 16px;
  }
  .strategy-grid { margin-top: 48px; grid-template-columns: 1fr; gap: 16px; }
  .strategy-grid article { height: 160px; min-height: 0; padding: 16px; box-sizing: border-box; text-align: center; }
  .strategy-grid article:nth-child(3) { height: 190px; }
  .strategy-grid article:nth-child(6),
  .strategy-grid article:nth-child(7) { height: 185px; }
  .strategy-grid .v-icon { font-size: 32px; }
  .strategy-grid h3 { margin-top: 8px; font-size: 20px; line-height: 30px; }
  .strategy-grid p { margin-top: 8px; font-size: 16px; line-height: 25px; }

  .industrial-growth { height: 562px; min-height: 562px; grid-template-columns: 1fr; }
  .industrial-image { min-height: 226px; }
  .industrial-copy { height: 336px; padding: 24px 16px 24px 40px; }
  .industrial-copy h2 { margin-top: 0; font-size: 30px; line-height: 40px; }
  .industrial-copy p { margin-top: 16px; font-size: 16px; line-height: 24px; }

  .contact-section,
  .contact-rail { min-height: 780px; }
  .contact-rail {
    padding: 56px 24px;
    display: flex;
    flex-direction: column;
    gap: 26px;
    align-items: stretch;
  }
  .contact-rail > img { order: -1; align-self: center; width: 315px; height: 252px; }
  .contact-copy h2 { font-size: 48px; line-height: 64px; }
  .contact-copy h3 { font-size: 24px; line-height: 36px; }
  .contact-copy p { margin-top: 26px; font-size: 16px; line-height: 24px; }
  .contact-copy .button { width: 149px; margin: 26px auto 0; display: flex; }

  .engine-banner { height: 350px; }
  .footer-rail { min-height: 593px; padding: 56px 64px 33px; grid-template-columns: 1fr; gap: 32px; }
  .footer-rail section { padding-top: 40px; }
  .footer-rail h2 { font-size: 24px; line-height: 32px; }
  .footer-rail a,
  .footer-rail p { font-size: 16px; line-height: 24px; }
}
</style>
