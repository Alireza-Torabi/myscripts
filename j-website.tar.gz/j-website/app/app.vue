<template>
  <NuxtLayout>
    <NuxtPage />
  </NuxtLayout>
</template>

<script setup lang="ts">
useHead({
  htmlAttrs: {
    dir: "ltr",
    lang: "en",
  },
});
</script>

<style lang="scss" src="../app/assets/styles/common.scss"></style>
