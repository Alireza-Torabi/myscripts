import vuetify, { transformAssetUrls } from 'vite-plugin-vuetify'

export default defineNuxtConfig({
  compatibilityDate: '2025-07-15',

  build: {
    transpile: ['vuetify'],
  },

  vite: {
    ssr: {
      noExternal: ['vuetify'],
    },

    plugins: [
      vuetify({
        autoImport: true,
      }),
    ],

    vue: {
      template: {
        transformAssetUrls,
      },
    },
  },
})